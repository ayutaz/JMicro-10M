"""Generated vs preserved natural2048 curriculum, same100M/full body+EOS CE."""
import argparse
import copy
import gc
import json
import math
import os
from pathlib import Path
import shutil
import signal
import statistics
import sys
import time
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import torch
from torch.nn.attention import SDPBackend,sdpa_kernel
from jmicro.eos_pilot import TrainView
from jmicro.experiment import ROOT,read_json,sha256,now
from jmicro.model import JMicroModel
from jmicro.shards import Shard
from jmicro.tokenizer import Tokenizer
from jmicro.japanese_evaluation import NativeLikelihood
from jmicro.training import atomic_json,implementation_hashes,gpu_lock,rng_state,restore_rng
from condition_positive_trainer import ConditionPositiveTrainer
from condition_transfer_curriculum import CurriculumTrainView
from cached_three_source_index import CachedThreeSourceIndex
from phase6_performance import alive,identity
from run_eos_short_pilot import equal_state
import run_condition_source_learning as prior
import run_condition_source_ranking as ranking
import run_complete_text_comparison as evaluation

RUN=ROOT/'reports/phase6/condition-transfer-comparison-20261006'
CONFIG=ROOT/'configs/phase6/condition_transfer_comparison.json'
PROBE_CONFIG=ROOT/'configs/phase6/condition_transfer_probe.json'
PROPOSAL=ROOT/'reports/phase6/condition_source_transfer_proposal.json'
DATA=Path('/home/aihub_ubuntu/jmicro-data/phase6/condition-transfer-curriculum-20261006-v2')
PREP_RUN=ROOT/'reports/phase6/condition-transfer-curriculum-20261006-v2'
TOTAL=100000000
CEILING=900
ARM='curriculum'
KIND='self_contained_conditional_curriculum_replacement_100M'
GOALS=dict(web=75000000,story=5000000,ordinary_textbook=10000000,conditional_textbook=10000000)
SOURCES=tuple(dict.fromkeys(('scripts/run_condition_transfer_comparison.py','scripts/run_condition_transfer_comparison.ps1',
    'scripts/review_condition_transfer_comparison.py','scripts/condition_transfer_curriculum.py',
    'scripts/prepare_condition_transfer_curriculum.py','scripts/prepare_condition_transfer_inputs.py',*prior.SOURCES)))
reference,check_reference=prior.reference,prior.check_reference
latest,reconcile,resume_gate,detail=prior.latest,prior.reconcile,prior.resume_gate,prior.detail


def source_contract():
    old,base,parent,_=prior.inspect(prior.CONFIG)
    p=read_json(PROPOSAL);result=read_json(prior.RUN/'compare-result.json');review=read_json(prior.RUN/'review.json')
    job=read_json(prior.RUN/'job.json');control=result['checkpoints']['large2048'];ev=result['evaluations']['large2048']
    if (job['status']!='complete' or alive(job) or p['parent']!=old['parent'] or p['scientific_teacher_tokens_new']!=TOTAL
            or p['comparison_total_teacher_tokens']!=2*TOTAL or p['source_teacher_tokens_each']!=GOALS
            or p['GPU_ceiling_seconds']!=CEILING or p['shape']!=old['shapes'] or p['Base_adopted'] or p['Chat_started'] or p['quantization_started']
            or p['natural_control']['checkpoint']!=control or control['additional_supervised_tokens']!=TOTAL
            or control['source_teachers']!=GOALS or control['outcome_weight']!=1 or ev['binding']!=control['binding']
            or ev['checkpoint_sha256']!=control['checkpoint_sha256'] or result['protected_test_used']
            or review['result_sha256']!=sha256(prior.RUN/'compare-result.json')
            or review['summaries']['large2048']['notes_sha256']!=sha256(ROOT/'reports/phase6/condition_source_learning_large2048_notes.json')):
        raise ValueError('Same-parent actual reviewed natural100M and one replacement proposal required')
    for ref in (p['evidence'],p['pair_evidence'],p['natural_control']['result'],p['natural_control']['review'],p['natural_control']['generation_notes']):check_reference(ref)
    positive=CurriculumTrainView(DATA,sha256(DATA/'manifest.json'))
    for rel,h in positive.manifest['source_sha256'].items():
        if sha256(ROOT/rel)!=h:raise ValueError('Accepted curriculum generator changed')
    audit=read_json(PREP_RUN/'ordinary-stream-audit.json')
    if (not all(audit['checks'].values()) or audit['goals']!=GOALS or audit['generated_manifest_sha256']!=positive.manifest_sha256
            or audit['accepted_generated_review_sha256']!=sha256(DATA/'content-review.json')
            or audit['natural_result_sha256']!=sha256(prior.RUN/'compare-result.json')):
        raise ValueError('Actual common100M ordinary teacher audit missing')
    return old,base,parent,control,ev,positive


def prepare_probe():
    if PROBE_CONFIG.exists():inspect(PROBE_CONFIG);return
    old,_,_,control,_,positive=source_contract()
    c=dict(research_kind=KIND,phase='probe',parent=old['parent'],original_config=old['original_config'],pool=old['pool'],
        accepted_compact_index=old['accepted_compact_index'],positive_data=dict(path=str(DATA),manifest_sha256=positive.manifest_sha256),
        arms={ARM:GOALS},outcome_weights={ARM:1},teachers_per_new_arm=TOTAL,total_comparison_teachers=2*TOTAL,
        peak_lr=.0002,optimizer_policy='inherit',shapes=old['shapes'],GPU_budget_seconds=120,total_new_GPU_ceiling_seconds=CEILING,
        loss='ordinary original body+EOS CE, outcome weight1',
        sampler_policy='Fresh explicit source fork from same2B+20M parent; original3 supervised target sequences equal; locally generated conditional bodies replace natural2048. Same seed42; conditional length/EOS/lexical distribution and row interleaving differ.',
        reused_control_checkpoint=dict(path=control['checkpoint'],sha256=control['checkpoint_sha256']),
        references=dict(proposal=reference(PROPOSAL),control_config=reference(prior.CONFIG),control_result=reference(prior.RUN/'compare-result.json'),
            control_review=reference(prior.RUN/'review.json'),control_notes=reference(ROOT/'reports/phase6/condition_source_learning_large2048_notes.json'),
            control_generation=reference(prior.RUN/'evaluation/large2048/evaluation/generation.json'),
            ordinary_stream_audit=reference(PREP_RUN/'ordinary-stream-audit.json'),manifest=reference(DATA/'manifest.json'),
            arrays=reference(DATA/'train.npz'),content_review=reference(DATA/'content-review.json'),content_notes=reference(DATA/'content-notes.json'),
            source_cases=reference(DATA/'transfer-probes.json'),source_text=reference(DATA/'train-source.json')),
        source_sha256={p:sha256(ROOT/p) for p in SOURCES},implementation=implementation_hashes(),
        quality_criteria_unchanged=True,old_numerical7_preserved=True,Base_adopted=False,Chat_adopted=False,
        protected_test_used=False,requested_five_steps_complete=False,scientific_teacher_tokens=0,created_at=now())
    scope(c);atomic_json(PROBE_CONFIG,c);inspect(PROBE_CONFIG)
    print('Actual accepted curriculum/reused natural100M probe frozen; no scientific training started',flush=True)


def scope(c):
    if (c['research_kind']!=KIND or c['arms']!={ARM:GOALS} or c['outcome_weights']!={ARM:1}
            or c['teachers_per_new_arm']!=TOTAL or c['total_comparison_teachers']!=2*TOTAL or c['total_new_GPU_ceiling_seconds']!=CEILING
            or c['peak_lr']!=.0002 or c['optimizer_policy']!='inherit'
            or c['shapes']!=dict(context=1024,batch=32,accumulation=1,backend='flash',compile_mode='reduce-overhead',dtype='bf16')
            or c['loss']!='ordinary original body+EOS CE, outcome weight1' or c['Base_adopted'] or c['Chat_adopted']
            or c['protected_test_used'] or c['requested_five_steps_complete'] or not c['quality_criteria_unchanged']):
        raise ValueError('Same100M weight1 Base-only curriculum scope differs')


def inspect(path):
    c=read_json(path);scope(c);old,base,parent,control,ev,positive=source_contract()
    if c['implementation']!=implementation_hashes() or c['source_sha256']!={p:sha256(ROOT/p) for p in SOURCES}:raise ValueError('Frozen comparison source differs')
    for ref in (*c['references'].values(),c['parent'],c['original_config'],c['accepted_compact_index'],c['reused_control_checkpoint']):check_reference(ref)
    if (c['parent']!=old['parent'] or c['pool']!=old['pool'] or c['shapes']!=old['shapes']
            or c['positive_data']!=dict(path=str(DATA),manifest_sha256=positive.manifest_sha256)
            or c['reused_control_checkpoint']!=dict(path=control['checkpoint'],sha256=control['checkpoint_sha256'])):
        raise ValueError('Same actual parent/material/control binding differs')
    folder=RUN/'probe' if path==PROBE_CONFIG else RUN
    if (folder/'job.json').exists() and alive(read_json(folder/'job.json')):raise ValueError('Actual comparison live; no duplicate GPU')
    if path==PROBE_CONFIG:
        if c['phase']!='probe' or c['GPU_budget_seconds']!=120:raise ValueError('Probe scope differs')
    elif path==CONFIG:
        measured=probe_evidence();timing,estimate=estimate_training(measured)
        if (c['phase']!='scientific' or c['probe_config_sha256']!=sha256(PROBE_CONFIG) or c['probe_result_sha256']!=sha256(RUN/'probe/result.json')
                or c['verification_GPU_seconds']!=measured['GPU_seconds'] or c['verification_teacher_tokens']!=measured['verification_teacher_tokens']
                or c['measured_timing']!=timing or c['estimated_GPU_seconds_with_margin']!=estimate
                or not math.isclose(c['GPU_budget_seconds']+measured['GPU_seconds'],CEILING,abs_tol=1e-9) or estimate+measured['GPU_seconds']>CEILING):
            raise ValueError('Actual measured bounded science differs')
    else:raise ValueError('Only frozen comparison configs allowed')
    return c,base,parent,control,ev,positive


def probe_evidence():
    job=read_json(RUN/'probe/job.json');r=read_json(RUN/'probe/result.json')
    if (job['status']!='complete' or alive(job) or not r['passed'] or r['config_sha256']!=sha256(PROBE_CONFIG)
            or r['GPU_seconds']!=job['GPU_elapsed_seconds'] or r['GPU_seconds']>120
            or not r['gate']['passed'] or not all(r['gate']['checks'].values())):raise ValueError('Actual curriculum CUDA resume/timing required')
    return r


def estimate_training(measured):
    record=measured['timing'];rows=record['histories']
    if len(rows)!=32 or any(not math.isfinite(r['seconds']) or r['seconds']<=0 for r in rows):raise ValueError('Actual32 continuous timings required')
    step=statistics.median(r['seconds'] for r in rows[8:]);teachers=record['verification_teacher_tokens']/32
    updates=math.ceil(TOTAL/teachers);warm=max(0.,sum(r['seconds'] for r in rows[:8])-8*step)
    save=(math.ceil(updates/250)+1)*record['terminal_save_seconds'];total=updates*step+warm+save
    return dict(steady_step_seconds=step,teachers_per_update=teachers,estimated_updates=updates,warmup_seconds=warm,save_seconds=save,estimated_training_seconds=total),total*1.3+300+40


def freeze():
    if CONFIG.exists():inspect(CONFIG);return
    c,*_=inspect(PROBE_CONFIG);c=copy.deepcopy(c);r=probe_evidence();timing,estimate=estimate_training(r)
    if estimate+r['GPU_seconds']>CEILING:raise ValueError('Measured science exceeds900s; retain evidence')
    c.update(phase='scientific',probe_config_sha256=sha256(PROBE_CONFIG),probe_result_sha256=sha256(RUN/'probe/result.json'),
        verification_GPU_seconds=r['GPU_seconds'],verification_teacher_tokens=r['verification_teacher_tokens'],GPU_budget_seconds=CEILING-r['GPU_seconds'],
        measured_timing=timing,estimated_GPU_seconds_with_margin=estimate,save_every_updates=250)
    atomic_json(CONFIG,c);inspect(CONFIG);print(json.dumps(dict(status='measured100M_curriculum_frozen',timing=timing,estimate=estimate)),flush=True)


def binding(c,path):
    return dict(config_sha256=sha256(path),arm=ARM,parent=c['parent'],short_manifest_sha256=c['pool']['manifest_sha256'],teacher_goals=GOALS,
        optimizer_policy='inherit',peak_lr=.0002,loss=c['loss'],study_kind=KIND,sampler_policy=c['sampler_policy'],outcome_weight=1,
        positive_manifest_sha256=c['positive_data']['manifest_sha256'])


def trainer_for(parent,pool,positive,b,device='cuda',context=1024,batch=32):
    trainer=ConditionPositiveTrainer(parent,pool,positive,GOALS,1,b,device,context,batch);trainer.spec['research_kind']=KIND
    trainer.lineage.update(kind='explicit-generated-curriculum-100M-constant-LR-fork',
        source_sampler_policy='Accepted local generated bodies+EOS; common original3 supervised sequences/parent Adam and cursor preserved; fresh source fork, no reheat.')
    return trainer


def summarize_transfer(rows,prepared):
    cases=prepared['cases'];ranking.validate_scores(rows,cases);keyed={r['index']:r for r in rows}
    pairs=[]
    for family in prepared['families']:
        f=family['index'];subset=[c for c in cases if c['family']==f]
        if len(subset)!=4 or {(c['branch'],c['candidate']) for c in subset}!={(b,k) for b in (0,1) for k in (0,1)}:raise ValueError('Complete two-condition family required')
        indexed={(c['branch'],c['candidate']):keyed[c['index']] for c in subset}
        for metric in ranking.METRICS:
            margins=[ranking.metric_value(indexed[(b,0)],metric)-ranking.metric_value(indexed[(b,1)],metric) for b in (0,1)]
            credit=[.5 if abs(m)<=1e-9 else float(m>0 if b==0 else m<0) for b,m in enumerate(margins)]
            pairs.append(dict(family=f,id=family['id'],split=family['split'],category=family['category'],metric=metric,
                credits=credit,margins=margins,both_correct=credit==[1.,1.],same_unique_candidate=margins[0]*margins[1]>0,
                context_margin_shift=margins[0]-margins[1]))
    aggregate={}
    for metric in ranking.METRICS:
        aggregate[metric]={}
        for split in ('all128','lexical_holdout','structural_holdout'):
            selected=[p for p in pairs if p['metric']==metric and (split=='all128' or p['split']==split)]
            aggregate[metric][split]=dict(families=len(selected),accuracy=sum(sum(p['credits']) for p in selected)/2/len(selected),
                both_correct=sum(p['both_correct'] for p in selected),same_unique_candidate=sum(p['same_unique_candidate'] for p in selected),
                aligned_context_margin_shift=sum(p['context_margin_shift']>0 for p in selected))
    return dict(aggregate=aggregate,pairs=pairs)


def transfer_scores(c,arm,checkpoint,heartbeat,check):
    folder=RUN/'transfer'/arm;terminal=folder/'result.json';cfg=sha256(CONFIG);cases_sha=c['references']['source_cases']['sha256']
    check_reference(checkpoint)
    if terminal.exists():
        saved=read_json(terminal)
        if saved['config_sha256']!=cfg or saved['checkpoint_sha256']!=checkpoint['sha256'] or saved['cases_sha256']!=cases_sha:raise ValueError('Saved transfer binding differs')
        return saved
    prepared=read_json(Path(c['references']['source_cases']['path']));before_rng=rng_state()
    state=torch.load(checkpoint['path'],map_location='cpu',weights_only=False);model=JMicroModel(state['model_config']).to('cuda').eval();model.load_state_dict(state['model'],strict=True)
    before={k:v.detach().cpu().clone() for k,v in model.state_dict().items()};scorer=NativeLikelihood(model,None,'cuda','bf16',16)
    hook=model.register_forward_pre_hook(lambda *_:check());rows=[]
    try:
        with sdpa_kernel(SDPBackend.MATH):
            for start in range(0,512,16):
                cases=prepared['cases'][start:start+16];path=folder/f'{start:04d}.json';check()
                if path.exists():
                    saved=read_json(path)
                    if saved['config_sha256']!=cfg or saved['checkpoint_sha256']!=checkpoint['sha256'] or saved['cases_sha256']!=cases_sha:raise ValueError('Saved transfer request differs')
                    scored=saved['rows']
                else:
                    scored=[dict(index=case['index'],**r) for case,r in zip(cases,scorer.score_encoded(cases),strict=True)]
                    ranking.validate_scores(scored,cases);atomic_json(path,dict(config_sha256=cfg,checkpoint_sha256=checkpoint['sha256'],cases_sha256=cases_sha,rows=scored))
                ranking.validate_scores(scored,cases);rows.extend(scored);heartbeat(arm+'-transfer128',completed_requests=len(rows),total_requests=512)
        checks=dict(weights_unchanged=all(torch.equal(before[k],v.detach().cpu()) for k,v in model.state_dict().items()),no_gradients=all(p.grad is None for p in model.parameters()),eval_mode=not model.training)
    finally:hook.remove();restore_rng(before_rng)
    checks['RNG_restored']=equal_state(before_rng,rng_state())
    if not all(checks.values()):raise ValueError('Read-only transfer scoring altered weights/RNG')
    result=dict(config_sha256=cfg,checkpoint_sha256=checkpoint['sha256'],cases_sha256=cases_sha,checks=checks,
        summary=summarize_transfer(rows,prepared),evaluated_requests=512,optimizer_updates=0,scientific_teacher_tokens=0,protected_test_used=False,
        limitations='Local generated state entailment, shared generator rules, one learned seed; not untouched real-world Japanese quality or Base adoption.')
    atomic_json(terminal,result);del state,model,before,scorer;gc.collect();torch.cuda.empty_cache();return result


def run(probe=False):
    path=PROBE_CONFIG if probe else CONFIG; c,base,parent,control,control_ev,positive=inspect(path)
    output=RUN/'probe' if probe else RUN; output.mkdir(parents=True,exist_ok=True)
    jp=output/'job.json'; old=read_json(jp) if jp.exists() else {}
    if old and old['config_sha256']!=sha256(path): raise ValueError('Prior job binding differs')
    if old.get('status')=='complete': print('Completed comparison retained; no duplicate GPU'); return
    prior_seconds=old.get('GPU_elapsed_seconds',0.); started,stopped=[None],[False]
    job=dict(status='setup',**identity(),config_sha256=sha256(path),started_at=old.get('started_at',now()),
        GPU_elapsed_seconds=prior_seconds,Base_adopted=False,protected_test_used=False,
        restart_command=f"scripts/run_condition_transfer_comparison.ps1 -Mode {'Probe' if probe else 'Train'} -Worker")
    for sig in (signal.SIGINT,signal.SIGTERM): signal.signal(sig,lambda *_:stopped.__setitem__(0,True))
    def check():
        if stopped[0]: raise InterruptedError('Interrupted; completed updates retained')
        if started[0] is not None and prior_seconds+time.monotonic()-started[0]>c['GPU_budget_seconds']: raise TimeoutError('Cumulative comparison GPU budget exhausted')
    def heartbeat(stage,**values):
        check(); job.update(stage=stage,heartbeat_at=now(),**values)
        if started[0] is not None: job['GPU_elapsed_seconds']=prior_seconds+time.monotonic()-started[0]
        atomic_json(jp,job)
    try:
        torch.set_num_threads(2); torch.use_deterministic_algorithms(True); heartbeat('setup')
        for relative in (*SOURCES,*c['implementation'],path.relative_to(ROOT).as_posix()):
            target=output/'source'/relative; target.parent.mkdir(parents=True,exist_ok=True)
            if target.exists() and target.read_bytes()!=(ROOT/relative).read_bytes(): raise ValueError('Source snapshot differs')
            if not target.exists(): shutil.copyfile(ROOT/relative,target)
        check_reference(c['accepted_compact_index']); pool=TrainView(c['pool']['pool'],c['pool']['manifest_sha256']); pool.index=CachedThreeSourceIndex(pool)
        if not pool.index.cache_reused: raise ValueError('Index must be reused')
        b=binding(c,path)
        def build(): return trainer_for(parent,pool,positive,b)
        with gpu_lock('cuda'):
            started[0]=time.monotonic(); heartbeat('gpu')
            if probe:
                gate=resume_gate(build,output/'resume-gate',sha256(path),check)
                folder=output/'timing'; folder.mkdir(parents=True,exist_ok=True); trainer=build(); cp=latest(folder)
                if cp is not None: trainer.load(cp)
                log=folder/'metrics.jsonl'; reconcile(log,trainer.update,parent['update'])
                with log.open('a',buffering=1) as stream:
                    while trainer.update-parent['update']<32:
                        try: check()
                        except (InterruptedError,TimeoutError): trainer.save(folder/'checkpoint.pt'); raise
                        row=trainer.step(); stream.write(json.dumps(row,allow_nan=False)+'\n')
                        if trainer.sampler.position%8==0: heartbeat('timing',completed_updates=trainer.sampler.position)
                cp=folder/'checkpoint.pt'; saved_seconds=trainer.save(cp); rows=[json.loads(s) for s in log.read_text().splitlines()]
                if any(not equal_state(row[k],reference_row[k]) for row,reference_row in zip(rows[:4],gate['histories'][0],strict=True)
                        for k in ('loss','gradient_norm','lr','token_digest','source_teachers')): raise ValueError('Probe trajectories differ')
                timing=dict(histories=rows,verification_teacher_tokens=trainer.supervised_tokens-parent['supervised_tokens'],
                    terminal_save_seconds=saved_seconds,checkpoint=str(cp),checkpoint_sha256=sha256(cp))
                result=dict(status='actual_generated_curriculum_resume_timing_complete',passed=True,gate=gate,timing=timing,
                    config_sha256=sha256(path),verification_teacher_tokens=gate['verification_teacher_tokens']+timing['verification_teacher_tokens'],
                    GPU_optimizer_updates=40,scientific_teacher_tokens=0,weights_discarded_for_science=True)
                del trainer; gc.collect(); torch.cuda.empty_cache()
            else:
                progress=output/'progress-result.json'
                result=read_json(progress) if progress.exists() else dict(checkpoints=dict(control=control),evaluations=dict(control=control_ev))
                if result['checkpoints']['control']!=control or result['evaluations']['control']!=control_ev: raise ValueError('Reused control changed')
                if ARM not in result['checkpoints']:
                    folder=output/ARM/'training'; folder.mkdir(parents=True,exist_ok=True); trainer=build(); cp=latest(folder)
                    if cp is not None: trainer.load(cp)
                    log=folder/'metrics.jsonl'; seconds=reconcile(log,trainer.update,parent['update'])
                    with log.open('a',buffering=1) as stream:
                        while trainer.sampler.source_teachers!=GOALS:
                            try: check()
                            except (InterruptedError,TimeoutError): trainer.save(folder/f'checkpoint-{trainer.update:08d}.pt'); raise
                            row=trainer.step(); seconds+=row['seconds']; stream.write(json.dumps(row,allow_nan=False)+'\n')
                            if trainer.sampler.position%20==0: heartbeat('training',teachers=row['additional_teacher_tokens'],teacher_budget=TOTAL,source_teachers=row['source_teachers'],loss=row['loss'])
                            if trainer.sampler.position%250==0: trainer.save(folder/f'checkpoint-{trainer.update:08d}.pt')
                    cp=folder/f'checkpoint-{trainer.update:08d}.pt'; trainer.save(cp); result['checkpoints'][ARM]=detail(trainer,cp,b,seconds)
                    atomic_json(progress,result); del trainer; gc.collect(); torch.cuda.empty_cache()
                if ARM not in result['evaluations']:
                    evaluation.RUN=output/'evaluation'; dev=Shard(Path(base['dev_shards']),'dev'); tok=Tokenizer(ROOT/base['tokenizer'])
                    result['evaluations'][ARM]=evaluation.evaluate(ARM,result['checkpoints'][ARM],dev,tok,base,b,heartbeat,check,started[0]+c['GPU_budget_seconds']-prior_seconds)
                    atomic_json(progress,result)
                result.setdefault('transfer',{})
                transfer_weights=dict(parent2B=c['parent'],natural100M=c['reused_control_checkpoint'],curriculum100M=dict(path=result['checkpoints'][ARM]['checkpoint'],sha256=result['checkpoints'][ARM]['checkpoint_sha256']))
                for arm,record in transfer_weights.items():
                    if arm not in result['transfer']:
                        result['transfer'][arm]=transfer_scores(c,arm,record,heartbeat,check)
                        atomic_json(progress,result)
                result.update(status='actual_curriculum100M_reused_natural100M_complete_pending_new80',config_sha256=sha256(path),
                    scientific_teacher_tokens=TOTAL,reused_control_teacher_tokens=TOTAL,total_comparison_teacher_tokens=2*TOTAL,
                    verification_teacher_tokens=c['verification_teacher_tokens'],verification_GPU_seconds=c['verification_GPU_seconds'],
                    ordinary_stream_audit=c['references']['ordinary_stream_audit'],Base_adopted=False,Chat_adopted=False,
                    protected_test_used=False,requested_five_steps_complete=False)
            check(); elapsed=prior_seconds+time.monotonic()-started[0]; result['GPU_seconds']=elapsed
            job.update(status='complete',stage='complete',completed_at=now(),GPU_elapsed_seconds=elapsed)
            atomic_json(output/('result.json' if probe else 'compare-result.json'),result)
    except BaseException as error:
        job.update(status='failed',error=repr(error)); raise
    finally:
        if started[0] is not None and job['status']!='complete': job['GPU_elapsed_seconds']=prior_seconds+time.monotonic()-started[0]
        atomic_json(jp,job)


if __name__=='__main__':
    if sys.version_info[:3]!=(3,12,7): raise RuntimeError('Pinned uv Python3.12.7 required')
    p=argparse.ArgumentParser(); modes=p.add_mutually_exclusive_group()
    for mode in ('prepare-probe','preflight-probe','probe','freeze','inspect'): modes.add_argument('--'+mode,action='store_true')
    args=p.parse_args()
    if args.prepare_probe: prepare_probe()
    elif args.preflight_probe: inspect(PROBE_CONFIG)
    elif args.freeze: freeze()
    elif args.inspect: inspect(CONFIG)
    else: run(args.probe)
